repita = True 

while repita == True:

    valor = int(input("Informe valor: "))
    taxa = int(input("Informe a taxa: "))
    tempo = int(input("Informe o tempo "))

    prestacao = (valor)+(valor*(taxa/100) * tempo)

    print("R$", prestacao, "este é valor da prestação deste funcionário. \n")

    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = True 
    else: 
        repita = False