repita = True 

while repita == True:

    a = int(input("Insira o valor de A: "))
    b = int(input("Insira o valor de B: "))
    
    a,b = b,a

    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = True 
    else: 
        repita = False