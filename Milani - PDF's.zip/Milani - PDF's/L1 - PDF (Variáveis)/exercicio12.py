repita = True 

while repita == True:

    razao = int(input("Informe a razão que você deseja: "))
    primeiro = int(input("Informe o valor do primeiro termo da sequência desta PA: "))
    
    decimotermo = (primeiro)+(razao*9)

    print(decimotermo, "é o valor do décimo termo desta sequência PA. \n")
    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = True 
    else: 
        repita = False 