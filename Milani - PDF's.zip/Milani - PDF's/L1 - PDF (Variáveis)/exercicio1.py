def quadrado(a):
    return a * a

repita = True 

while repita == True:

    a = int(input("Informe o primeiro número desejado: "))
    
    quadrado = (a*a)
    print(str(quadrado) +", este é seu número")
    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = True 
    else: 
        repita = False