repita = True 

while repita == True:

    catetooposto = int(input("Informe o valor do cateto oposto deste triângulo retângulo: "))
    catetoadjacente = int(input("Informe o valor do cateto adjacente deste triângulo retângulo: "))

    hipotenusa = (catetooposto*catetooposto)+(catetoadjacente*catetoadjacente)
    
    print(hipotenusa, "é o valor da hipotenusa deste triângulo retângulo. \n")
    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = True 
    else: 
        repita = False 