repita = True 

while repita == True:

    razao = input("Insira um número com 3 digitos: ")
    
    soma = int(razao) + int(razao[2] + razao[1] + razao[0])  
    soma = str(soma) 
    
    somaposi = int(soma[0]) * 1
    somaposi = somaposi + (int(soma[1]) * 2)
    somaposi = somaposi + (int(soma[2]) * 3)
    
    somaposi = str(somaposi)
    
    print("O digito é ", somaposi[1]) 
    
    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = True 
    else: 
        repita = False 