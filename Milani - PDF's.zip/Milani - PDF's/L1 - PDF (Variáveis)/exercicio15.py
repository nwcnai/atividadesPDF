repita = True 

while repita == True:

    raio = int(input("Informe o raio desta lata de óleo: "))
    altura = int(input("Informe a altura desta lata de óleo: "))
    pi = (3.1416)

    volume = (pi)*(raio*raio)*(altura)

    print(volume, "este é valor do volume desta lata de óleo. \n")

    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = True 
    else: 
        repita = False