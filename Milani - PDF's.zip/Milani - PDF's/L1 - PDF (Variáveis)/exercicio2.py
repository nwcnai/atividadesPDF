repita = True 

while repita == True:

    a = int(input("Informe a dezena do primeiro número desejado: "))
    b = int(input("Informe a unidade do primeiro número desejado: "))

    c = int(input("Informe a dezena do segundo número desejado: "))
    d = int(input("Informe a unidade do segundo número desejado: "))
    
    print(a,b, "foram os números do primeiro valor digitados pelo usúario. \n")
    print(c,d, "foram os números do segundo valor digitados pelo usúario. \n")
    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = True 
    else: 
        repita = False