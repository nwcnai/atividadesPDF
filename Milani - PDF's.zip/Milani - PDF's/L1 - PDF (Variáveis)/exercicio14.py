repita = True 

while repita == True:

    valorinicial = int(input("Informe o valor do produto: "))
    
    valorcomdesconto = (valorinicial*0.91)

    print("R$", valorcomdesconto, "este é valor em reais a ser pago (com os 9 porcento de desconto). \n")

    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = True 
    else: 
        repita = False