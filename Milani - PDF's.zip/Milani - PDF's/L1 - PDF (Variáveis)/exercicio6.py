repita = True 

while repita == True:

    salario = int(input("Informe o valor do seu salário mínimo: "))
    quilowatts = int(input("Informe a quantia de quilowatts gastos em sua residência: "))
    
    razao = (salario/quilowatts)
    umwatts = (salario/700)  
    # 100 watts custa 1/7 do salario
    # logo, 10 watts custa 1/70 e 1 watts custa salario/700
    
    valordacontainicial = (umwatts*quilowatts)
    valorcomdesconto = (valordacontainicial*0.90)

    
    print(umwatts, "este é valor de cada quilowatts gasto por esta residência. \n")
    print(valordacontainicial, "este é valor em reais a ser pago (sem os 10 porcento de desconto). \n")
    print(valorcomdesconto, "este é valor em reais a ser pago (com os 10 porcento de desconto). \n")

    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = True 
    else: 
        
        repita = False