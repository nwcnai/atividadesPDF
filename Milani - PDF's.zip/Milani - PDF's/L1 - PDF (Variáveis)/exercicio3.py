repita = True 

while repita == True:

    a = int(input("Informe o número desejado: "))

    print(a, "foram os números do primeiro valor digitados pelo usúario. \n")
    
    sucessor = (a+1)
    print(sucessor, "este é o número sucessor ao valor anteriormente inserido pelo usuário. \n")
    
    antecessor = (a-1)
    print(antecessor, "este é o número antecessor ao valor anteriormente inserido pelo usuário. \n")
    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = True 
    else: 
        repita = False