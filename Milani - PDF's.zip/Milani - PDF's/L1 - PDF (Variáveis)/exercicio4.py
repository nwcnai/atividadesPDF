repita = True 

while repita == True:

    numero = input("Informe o número desejado: ")
    
    print(numero[0], "é correspondente a centena do número inserido pelo usuário. \n")
    print(numero[1], "é correspondente a dezena do número inserido pelo usuário. \n")
    print(numero[2], "é correspondente a unidade do número inserido pelo usuário. \n")
    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = True 
    else: 
        repita = False