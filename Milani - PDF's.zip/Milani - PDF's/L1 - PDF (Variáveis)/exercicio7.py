repita = True 

while repita == True:

    a = int(input("Informe o valor do primeiro lado deste retângulo: "))
    b = int(input("Informe o valor do segundo lado deste retângulo: "))
    
    perimetro = (a+a+b+b)
    area = (a*b)

    print(perimetro, "é o perímetro referente aos números digitados pelo usúario. \n")
    print(area, "é a área referente aos números digitados pelo usúario. \n")
    op2 = int(input("Deseja repetir?\n1- Sim\n2- Não"))

    if op2 == 1:
        repita = True 
    else: 
        repita = False