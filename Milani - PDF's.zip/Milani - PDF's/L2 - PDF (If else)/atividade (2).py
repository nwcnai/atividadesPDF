a = int(input("Digite o valor de A: "))
b = int(input("Digite o valor de B: "))

if a % b == 0:
    print(f"{a} é divisível por {b}")
else:
    print(f"{a} não é divisível por {b}")
20